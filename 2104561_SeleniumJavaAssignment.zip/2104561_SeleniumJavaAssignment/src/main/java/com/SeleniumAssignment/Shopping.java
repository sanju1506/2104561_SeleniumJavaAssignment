package com.SeleniumAssignment;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Shopping {

	public  static void UpdateInformation() {
		//invoking chrome driver
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		//Maximizing the window
		driver.manage().window().maximize();
		String userName = "Sanjaybajjuri15@gmail.com";
		String Pswd = "SanJay";
		String Fname = "Harish";
		//Redirecting to website
		String link = "http://automationpractice.com";
		driver.get(link);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);//Waiting searching for the element using implicit wait
		driver.findElement(By.className("login")).click();//finding the login button
		//Entering the username,password and signing in
		driver.findElement(By.id("email")).sendKeys(userName);
		driver.findElement(By.id("passwd")).sendKeys(Pswd.toLowerCase());
		driver.findElement(By.id("SubmitLogin")).click();
		//Searching for the personal information
		driver.findElement(By.partialLinkText("PERSONAL")).click();
		//updating the firstName 
		driver.findElement(By.id("firstname")).clear();
		driver.findElement(By.id("firstname")).sendKeys(Fname);
		driver.findElement(By.name("submitIdentity")).click();
		//Quitting the browser
		driver.quit();
		}
			public static void Order() {
				//invoking the chrome browser
				WebDriverManager.chromedriver().setup();
				WebDriver driver = new ChromeDriver();
				String userName = "Sanjaybajjuri15@gmail.com";
				String Pswd = "SanJay";
				//redirecting to website
				String link = "http://automationpractice.com";
				driver.get(link);
				//maximizing the window
				driver.manage().window().maximize();
				//Entering the username,password and signing in
				driver.findElement(By.className("login")).click();
				driver.findElement(By.id("email")).sendKeys(userName);
				driver.findElement(By.id("passwd")).sendKeys(Pswd.toLowerCase());
				driver.findElement(By.id("SubmitLogin")).click();
				//clicking on the T-shirt
				driver.findElement(By.linkText("T-SHIRTS")).click();
				Actions act = new Actions(driver);
				WebElement mo = driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li/div/div[2]/h5"));
				act.moveToElement(mo).build().perform();
				WebDriverWait wait = new WebDriverWait(driver , Duration.ofSeconds(10));
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText("Add to cart")));
				WebElement Cart = driver.findElement(By.linkText("Add to cart"));
				act.moveToElement(Cart);
				act.click().build().perform();
				//forwarding to next step
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.linkText("Proceed to checkout")));
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				//forwarding to next step
				driver.findElement(By.linkText("Proceed to checkout")).click();
				//forwarding to next step
				driver.findElement(By.linkText("Proceed to checkout")).click();
				//confirming the address and forwarding to next step
				driver.findElement(By.name("processAddress")).click();
				//Accepting the terms and conditions by clicking the checkbox
				driver.findElement(By.xpath("//input[@type='checkbox']")).click();
				
				driver.findElement(By.name("processCarrier")).click();
				//Select the payment method for order
				driver.findElement((By.className("bankwire"))).click();
				//Order confirming
				driver.findElement(By.xpath("//*[@id=\"cart_navigation\"]/button")).click();
				//Getting the text for verifying
				String B = driver.findElement(By.xpath("//*[@id=\"center_column\"]/div/br[5]")).getText();
				driver.findElement(By.className("account")).click();
				//Opening the order history
				driver.findElement(By.linkText("ORDER HISTORY AND DETAILS")).click();
				//Getting order id
				String A = driver.findElement(By.xpath("//*[@id=\"order-list\"]/tbody/tr[1]/td[1]")).getText();
				//Verifying the order
				if (A.contains(B)) {
					System.out.println("Order placed Successfully.");
				}else {
					System.err.println("Order Not placed.");
				}
				driver.quit();
			}
	

	public static void main(String[] args) {
		UpdateInformation();
		Order();
		

	}

}
